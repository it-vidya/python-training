a,b=10,20
t=(b,a)
a,b=t
