'''
name='Hello Python'
for c in name:
	print(c)

a=[1,2,3,4,5,6,7,8,9,0]
for c in a:
	print(c)

a={1,2,3,4,5,6,7,8,9,0}
for c in a:
	print(c)
	'''
# for loop for dict

num=12
for a in range(2,num):
	if(num%a==0):
		print('Not prime!')
		break;
else:
	print('Prime!!')
	
		
		
		
		
		
		
		
		
		
		
		
		