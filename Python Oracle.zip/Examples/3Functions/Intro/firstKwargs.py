def abc(**kwargs):
 print(kwargs)

abc(name="PYTHON" ,topic="keyworded Arguments")
