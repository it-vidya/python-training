def myFunction(a='10',b=100):
	print(a)
	print(b)
	print('invoked..!')
myFunction(50)