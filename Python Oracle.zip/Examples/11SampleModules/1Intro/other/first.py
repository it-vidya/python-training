def sayHi():
	print('Hiiii')
	
def sayHello():
	print('Hello')