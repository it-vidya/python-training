import logging
logging.warning('Watch out!') # will print a message to the console
logging.info('I told you so') # will not print anything
logging.debug('Watch out!')