import time;
from datetime import date;
print(date.today)
print(date.fromtimestamp(time.time()))