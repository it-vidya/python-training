import third
third.A.i=10
a=third.A()
a.sayHi()
print a.i,third.A.i