s=range(10)
d1=iter(s)
print(d1)


print(d1.__next__())
print(d1.__next__())
print(d1.__next__())
print(d1.__next__())
print(d1.__next__())
'''
print(d1.next())
print(d1.next())
print(d1.next())
print(d1.next())
'''
