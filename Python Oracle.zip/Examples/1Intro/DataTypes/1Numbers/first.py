varBool= True #(True is 1 , False is 0)
varInt = 17 ,
varLong = 0xDEFABCECBDAECBFBAEL
varFloat = 15.20
varComplex = -.65+10J
print varInt
print varLong
print varFloat
print varComplex
print type(varInt)