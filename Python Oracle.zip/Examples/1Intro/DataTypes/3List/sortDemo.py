#li=[5,6,4,2,9,3,8]
#li=['a','v','w','c','b']
li=['Python','Session','John','Alpha','Beta']

li.sort(reverse=True)
print(li)