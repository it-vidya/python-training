l=['a','b','c','d','e','f']
print(len(l))
sum(l) 
max(l) 
min(l) 
l.append('g')
l2=['h','i','j','k']
l.extend(l2)
l.insert(2,'z')
l.pop(2)
l.pop()
l.remove('a')
l.reverse()
l.sort(reverse=True)  
l.count('a')







#stack operations->
stack=[]
stack.append('a')
stack.append('b')
stack.append('c')
stack.pop()
stack.pop()
stack.pop()

#queue operations:
queue=[]
queue.append('a')
queue.append('b')
queue.append('c')
queue.pop(0)
queue.pop(0)
queue.pop(0)

#dequeue