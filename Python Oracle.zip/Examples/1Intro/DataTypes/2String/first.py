str = 'HelloWorld,This is a simple string'

print str          # Prints complete string
print str[0]       # Prints first character of the string
print str[2:5]     # Prints characters starting from 3rd to 5th
print str[2:] 
print str[:7]      # Prints string starting from 3rd character
print str * 2      # Prints string two times
print str + "TEST" # Prints concatenated string
print str[0:5:2] 





print str[::-1]

#print str[-1]


#print str[5:2:-1];print str[::-1];
str[-3]
print str[-1:-5:-1]