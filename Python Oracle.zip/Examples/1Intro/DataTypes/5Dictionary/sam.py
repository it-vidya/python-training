a={0}
print(type(a))
print(isinstance(a,str))

