d={'name':'Saravan', 'id':111 , 'dept': 'SNS'}
k=list(d.keys())
print(type(d.values()))
print(type(k))



















'''for (k,v) in zip(d.keys(),d.values()):
	print(str(k)+'=='+str(v))
'''