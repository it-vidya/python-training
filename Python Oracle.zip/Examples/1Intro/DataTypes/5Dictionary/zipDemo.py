li=['id','name','dept']
li2=['12','John','QE']
z=dict(zip(li,li2))
print(z)

